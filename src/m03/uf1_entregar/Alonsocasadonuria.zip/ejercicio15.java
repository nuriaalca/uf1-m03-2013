/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package m03.uf1_entregar;

/**
 *
 * @author Pedro
 */
public class ejercicio15 {
 public static void main(String[] args) {
     int x = 12, j = 5, k = 0;
     if(0==x %4);
     for(j=0;j<10;j=j+4)
         k=k+j;
     else{
    for(j=0;j<10;j=j+2)
        k=k´+j;
}
}


